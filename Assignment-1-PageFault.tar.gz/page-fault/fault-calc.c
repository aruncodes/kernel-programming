#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/moduleparam.h>

#include <linux/list.h>
#include <linux/slab.h>
#include <linux/sched.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Arun Babu");

struct node {
	int pid;
	int maj_flt,min_flt;
	char *name;

	struct list_head list; /* kernel's list structure */
};

LIST_HEAD(proc_head);

extern void (*pf_hook)(struct task_struct *tsk);

void pf_hook_imp(struct task_struct *tsk) {

	//Linked List op

	struct node *process;

	list_for_each_entry(process, &proc_head, list) {
		if(process -> pid == tsk -> pid) {
			process -> min_flt = tsk -> min_flt;
			process -> maj_flt = tsk -> maj_flt;
			return;
		}
	}

	process = kmalloc(sizeof(struct node),GFP_KERNEL);
	process -> pid = tsk -> pid;
	process -> min_flt = tsk -> min_flt;
	process -> maj_flt = tsk -> maj_flt;
	process -> name = tsk -> comm;

	list_add(&(process->list), &proc_head);

	return;
}

static int __init start(void) {
	printk(KERN_INFO "Module loaded for page fault calc \n");

	// Enable hook
	pf_hook = &pf_hook_imp;

	return 0;
}

static void __exit stop(void) {
	struct node *process,*tmp;

	printk(KERN_INFO "Exiting page fault calc \n");

	//Disable hook
	pf_hook = NULL;

	//Print collected info
	printk(KERN_INFO "PID \t NAME \t\t MIN \t MAJ\n");

	//Linklist ops
	list_for_each_entry(process, &proc_head, list) {
		printk(KERN_INFO "%d \t %-16s \t %d \t %d\n", process->pid,process->name,process->min_flt,process->maj_flt);
	}

	//Clean up
	list_for_each_entry_safe(process,tmp,&proc_head,list) {
		list_del(&(process->list));
		kfree(process);
	}
}

module_init(start);
module_exit(stop);