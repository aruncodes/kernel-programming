#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/moduleparam.h>
#include <linux/tty.h>

#include <linux/sched.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Arun Babu");

static int pid = -1;

module_param(pid,int,0);
MODULE_PARM_DESC(pid,"Process ID");
int console_print(size_t size, const char *fmt, ...);

//HOOKs
static long nr_switch = 0,switch_per_prio=0,switch_per_cpu=0;
static long prev_clock=-1,avg_time_took=0,avg_time_per_prio=0,avg_time_per_cpu=0;
static long time_took;
static int prio=0,cpu=-1,prio_change=0,mig=0;
//Get exported symbols
extern void (*prochook)(struct task_struct *tsk,int cpu,unsigned long clock);

//Per proc hook impl
void proc_hook_imp(struct task_struct *tsk,int curr_cpu,unsigned long clock) {

	if(tsk->pid == pid) {
		//Our process
		nr_switch++;
		switch_per_prio++;
		switch_per_cpu++;

		if(prev_clock == -1) {
			prev_clock = clock;
			prio = tsk -> prio;
			cpu = curr_cpu;
		} else {
			time_took = clock - prev_clock;

			if(prio != tsk->prio) {
				printk(KERN_INFO "Priority changed from %d to %d, Avg time: %ld us (%ld)\n\r",\
					prio,tsk->prio,avg_time_per_prio/1000,switch_per_prio);
				avg_time_per_prio = 0;
				switch_per_prio = 1;
				prio = tsk->prio;
				prio_change++;
			}

			if(cpu != curr_cpu) {
				printk(KERN_INFO "CPU changed from %d to %d, switches: %ld, time: %ld us\r\n",
					cpu,curr_cpu,switch_per_cpu,avg_time_per_cpu/1000);
				avg_time_per_cpu = 0;
				switch_per_cpu = 1;
				cpu = curr_cpu;
				mig++;
			}

			avg_time_took = avg_time_took + ((time_took - avg_time_took)/nr_switch); //Running avg
			avg_time_per_prio = avg_time_per_prio + ((time_took - avg_time_per_prio)/switch_per_prio); //Running avg
			avg_time_per_cpu = avg_time_per_cpu + ((time_took - avg_time_per_cpu)/switch_per_cpu); //Running avg
		}
	}
	prev_clock = clock;
}

//HOOKs end

static int __init start(void) {

	console_print(100,"Initialzed hook,collecting data of %d\r\n",pid);
	prochook = &proc_hook_imp;
	return 0;
}

static void __exit stop(void) {

	console_print(100,"No. of context switches : %u\r\n",nr_switch);
	console_print(100,"Last CPU: %d, Last Priority : %d\r\n",cpu,prio);
	console_print(100,"No. of priority changes : %d\r\n",prio_change);
	console_print(100,"No. of CPU migrations : %d\r\n",mig);
	console_print(100,"Avg. time of context switches : %lu us\r\n",avg_time_took/1000);

	prochook = NULL;

	console_print(100,"Mod exit\r\n");
}

module_init(start);
module_exit(stop);

static void printString(char *string) {
    struct tty_struct *tty;
    tty = get_current_tty();

    if(tty != NULL) { 
        (tty->driver->ops->write) (tty, string, strlen(string));
    } else
        printk("tty equals to zero");
}

int console_print(size_t size, const char *fmt, ...){
    va_list args;
    int i;
    char buf[size];

    va_start(args, fmt);
    i = vsnprintf(buf, size, fmt, args);
    va_end(args);

    printString(buf);

    return i;
}