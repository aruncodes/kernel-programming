#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/moduleparam.h>
#include <linux/tty.h>

#include <linux/sched.h>

#include "proc_list.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Arun Babu");

int console_print(size_t size, const char *fmt, ...);
struct node* proc_node;

//HOOKs
static long nr_switch = 0;
static long prev_clock=-1,avg_time_took=0,tmp;;
static long time_took;

//Get exported symbols
extern void (*cs_hook)(int cpu,int pid,char *name,unsigned long clock);
extern void get_nr_running(void (*callback)(int cpu,unsigned long nr_r));
extern void (*mig_hook)(int pid,int src,int dst); //Migration hook
extern void (*prochook)(struct task_struct *tsk,int cpu,unsigned long clock);

//RQ length callback
void rq_callback(int cpu,unsigned long nr_running) {
	// console_print(100,"CPU: %d, RQ_length: %d\r\n",cpu,nr_running);
	printk(KERN_INFO "CPU: %d, RQ_length: %lu\r\n",cpu,nr_running);
}

//Migration hook implementation
void mig_hook_imp(int pid,int src,int dst) {
	printk(KERN_INFO"Task:%d migrated from %d to %d\r\n",pid,src,dst);
}

//Context switch
void cswitch_hook_imp(int cpu,int pid,char *name,unsigned long clock) {
	nr_switch++;

	if(prev_clock == -1) {
		prev_clock = clock;
	} else {
		time_took = clock - prev_clock;

		if(time_took > 0) {
			//Check if already exists
			proc_node = get_proc(pid);

			if(proc_node == NULL) {
				add_proc(NULL,pid,name,cpu,1,time_took);
			} else {
				proc_node -> switches++;
				proc_node -> total += time_took;

				tmp = proc_node -> avg_time_took;
				proc_node -> avg_time_took = tmp + ((time_took - tmp)/nr_switch); //Running avg
				
				avg_time_took = avg_time_took + ((time_took - avg_time_took)/nr_switch); //Running avg
			}
		}
	}

	//Print for every 500 CSs
	if(nr_switch % 500 == 0) {
		get_nr_running(rq_callback);
	}
	prev_clock = clock;
}


//HOOKs end

static int __init start(void) {

	cs_hook = &cswitch_hook_imp;
	mig_hook = mig_hook_imp;
	console_print(100,"Initialzed hook, collecting data..\r\n");
	return 0;
}

static void __exit stop(void) {
	struct node *proc_node;

	console_print(100,"No. of context switches : %u\r\n",nr_switch);
	console_print(100,"Avg. time of context switches : %lu us\r\n",avg_time_took/1000);

	list_for_each_entry(proc_node,&proc_list_head,list) {
		console_print(200,"%5d (%-16s) CPU:%d CS:%6d Time: %5d us Total: %5d us\n\r",
			proc_node->pid,proc_node->name,proc_node->cpu,proc_node->switches,proc_node->avg_time_took/1000,proc_node->total/1000);
	}

	dealloc_list();

	cs_hook = NULL;
	mig_hook = NULL;
	console_print(100,"Mod exit\r\n");
}

module_init(start);
module_exit(stop);

static void printString(char *string) {
    struct tty_struct *tty;
    tty = get_current_tty();

    if(tty != NULL) { 
        (tty->driver->ops->write) (tty, string, strlen(string));
    } else
        printk("tty equals to zero");
}

int console_print(size_t size, const char *fmt, ...){
    va_list args;
    int i;
    char buf[size];

    va_start(args, fmt);
    i = vsnprintf(buf, size, fmt, args);
    va_end(args);

    printString(buf);

    return i;
}