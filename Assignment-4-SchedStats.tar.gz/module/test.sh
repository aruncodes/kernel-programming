#!/bin/bash

APP="leafpad"
PRIO=99

# sudo ls
for i in $(seq 1 5);
do
	$APP &
	PID[$i]=$(pidof $APP)
	PIDArr=(${PID[$i]})
	PID[$i]=${PIDArr[0]}
	# echo ${PID[$i]}
	sudo chrt -r -p $PRIO ${PID[$i]}
	# pkill leafpad
done

sudo insmod sched_stats.ko
sleep 5
sudo rmmod sched_stats 

for i in ${PID[*]};
do
	# echo $i
	kill $i
done