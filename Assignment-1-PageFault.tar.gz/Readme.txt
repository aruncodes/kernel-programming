
Arun Babu
143050032

Assignment 1 :- Tracking per process page faults

--------------------------
Where the kernel hook is written?

The part where page faults are handled is fault.c in the dirctory
arch/x86/mm/fault.c . So I added the hook to that file where the 
page fault is dealt by the do_page_fault() function.

--------------------------

How did the hook work?

I added a function pointer and initialized it to NULL. I exported
the symbo so that kernel modules can access it. Then I added
the code to execute the function when it is not NULL. That is inside
the do_page_fault() function.
When the module is inserted, It will replace the function pointer 
with address of its implementation inside kernel. So when pagefault 
occurs, the function in module will be called. When the module exits, 
it is changed back to NULL.

--------------------------

How to apply patch?

The patch is to be applied to fault.c file. Assuming you are inside the kernel source root, it can be applied as

patch arch/x86/mm/fault.c < fault.c.patch

Then you need to compile and install kernel.

--------------------------

How to get page fault info?

When the patched kernel is booted up, insert the fault-calc.ko module. 
When it is inserted, it will be storing all the page fault info into memory.
Now remove the module using rmmod and all the information will be dumped to 
logs. You can view them using 'dmesg | less' . The data collected are Process ID, 
Process Name, Majot Page fault and Minor page fault counts.

---------------------------
Instructions on how to execute

Navigate to 'page-fault' folder where 'fault-page.c' LKM is located

make
sudo insmod fault-page.ko
<wait for some time to capture pahe faults>
sudo rmmod fault-page
dmesg | less

See the log to find the output appended to the last.