#ifndef _PROC_LIST_H
#define _PROC_LIST_H 

#include <linux/list.h>
#include <linux/slab.h>
#include <linux/sched.h>

struct node {
	unsigned long switches,avg_time_took,total;
	int pid,cpu;
	struct task_struct *task;
	char *name;

	struct list_head list; /* kernel's list structure */
};

LIST_HEAD(proc_list_head);

void add_proc(struct task_struct *tsk,int pid,char *name,int cpu,unsigned long switches,unsigned long avg_time_took) {

	struct node *proc_node;

	proc_node = kmalloc(sizeof(struct node),GFP_KERNEL);
	proc_node -> task = tsk;
	proc_node -> pid = pid;
	proc_node -> cpu = cpu;
	proc_node -> name = name;
	proc_node -> total = avg_time_took;
	proc_node -> switches = switches;
	proc_node -> avg_time_took = avg_time_took;

	list_add(&(proc_node->list),&proc_list_head);
}

struct node* get_proc(int pid) {
	struct node *proc_node;

	list_for_each_entry(proc_node,&proc_list_head,list) {
		if(proc_node->pid == pid) {
			return proc_node;
		}
	}
	return NULL;
}

void dealloc_list(void) {

	struct node *proc_node,*tmp;

	list_for_each_entry_safe(proc_node,tmp,&proc_list_head,list) {
		list_del(&proc_node->list);
		kfree(proc_node);
	}
}

#endif